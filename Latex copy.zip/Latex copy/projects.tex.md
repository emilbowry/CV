% chktex-file 8
\section{Projects and Additional Experience}
\par
\ifattr{math_based}
{\input{published/plt.tex}
\input{published/editor.tex}
\input{published/ast_deb.tex}
}{
}
\input{projects/phasor_average_estimator.tex}

\input{projects/neuronal_data_analysis.tex}

\input{projects/icloud_messaging_service.tex}

\input{projects/automated_note_reasoning.tex}

\input{projects/module_type_objects.tex}




