\section{Education}
\textbf{Trinity College, University of Cambridge}
\begin{itemize}
	\item[] {\sl BA, Engineering Tripos}, 2020-2025
\end{itemize}
% Note: Degree awarded unclassified due to medical intermission preventing completion of Part IIB
\textbf{Judge Business School, University of Cambridge}
\begin{itemize}
	\item[] {\sl Accelerate Cambridge}, August 2022-July 2023
\end{itemize}
% Sponsorship for the startup by the University let me access this business school course + resources