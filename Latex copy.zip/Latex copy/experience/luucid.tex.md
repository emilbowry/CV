% chktex-file 8
\employer{Luucid.tech}
\location{Cambridge}
\dates{August 2022 - October 2023}
\title{\textbf{Co-founder}}
\begin{position}
    \vspace*{-.1in}
    \begin{itemize}
        \item Created novel electrochemical and material mechanisms for detecting spiking agents in beverages.
        \item Determined product-market fit and commercial viability of scientific research.
        \ifattr{math_based}{%
            \item Sponsorship by University of Cambridge's startup incubator.
        }{}
    \end{itemize}
\end{position}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 1. Bridged the gap between theoretical chemistry and viable consumer electronics hardware constraints.


% 2.a Research skills, used cross domain knowledge to find an exploitable property of the chemical, 
%  looked at the cyclohexanone deriviative of MDMA, Ketamine, used datasheets to determine what properties it had
%  found that it should not be used in conjunction with certain metal alloys since it causes corrosion
%  realised this implies resistivity changes, hence explotable in electrochemical mechanisms to modify a signal
% 2.b Unafraid to criticise an error in senior staff, originally the idea was to use a straw + reagent detection
% 2.c Leadership, managed a few post-docs
% 2.d Grant writing to UKRI
% 2.e Sponsorship by University of Cambridge's startup incubator ` Accelerate Cambridge`, was in the top 20 start-ups out of cambridge in 2022
% 2.f  Determining product-market fit and commercial viability of scientific research

% 3. Standard chemistry to unique problem

% 4. **NO**

% 5. **NO**

