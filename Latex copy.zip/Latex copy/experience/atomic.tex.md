% chktex-file 8
\employer{Atomic Media}
\location{Nottingham}
\dates{April 2022 - August 2022}
\title{\textbf{Software Development and Business Intern}} % Shorter name 
\begin{position}
    \vspace*{-.1in}
    \begin{itemize}
        \item Built an anomaly detection system that analyses fuel levels in a vehicle fleet to infer when there may have been an incident of fuel theft.
        \ifattr{math_based}{%
        }{%
            \item Analysed new business opportunities and ventures, writing insight articles.
        }
        \item Led skill days, which taught developers the low-level networking implementations of the tools they use: \small\url{https://github.com/emilbowry/NetworkProgrammingLesson} 
        \item Organised the weekly cyber-security brief about emerging threats and vulnerabilities. 
    \end{itemize}
\end{position}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% 1. `Anomaly detection`: Hard to determine statistic for a large dataset of vehicals

% 2.a `Anomaly detection`: Self taught machine learning techniques (hadn't been covered in courses yet)
%     - Forensic Data Analysis: Identifying patterns in noisy, real-world data (fuel logs).
% 2.b `Skill days`: Competancy to teach senior developers skills while being an intern
% 2.c `Cyber-security': Awareness to big-picture security issues and external factors in software development

% 3. **NO**

% 4.a Statistical methods and Supervised machine learning algorithm (not really that advanced)
% 4.b Time-Series Analysis: Assuming fuel theft detection involved looking for deviations from seasonality or expected consumption curves (Regression residuals).
% 5. **NO**
