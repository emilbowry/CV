\title{\textbf{Algorithmic Trading resource:}}  % NEEDS REFINING AND MAKING PUBLIC
\location{%
    \makebox[0pt][r]{{\small{\url{https://github.com/emilbowry/algorithmicTrading}}}} 
}
\begin{position}
\vspace*{-0.25in}
\par
A teaching resource that develops and implements knowledge gained in my signals processing, statistics, systems and other engineering courses; research into advanced mathematics to develop examples of: Quantitative Risk Modelling, 
Alpha Generation and Backtesting Engines.
\end{position}


% A teaching resource that develops and implements knowledge gained in my signals processing, statistics, systems and other engineering courses, as well as other information I learnt from Dexter's Notes of the Mathematics Tripos.
% This includes appllications of:
% \begin{itemize} 
%         \item Analysis tools like: K-means clustering, linear regression
%         \item Stastical tests like Augmented Dicky-Fuller, Variance Ratio, Generalised Autoregressive Conditional Heteroskedasticity, and Stationarity Analysis
%         \item Signal Processing techniques including Fourier, Wavelet and Hilbert transforms, continuous and discrete filters.
%         \item Optimisation techniques, it covers: linear programming, non-linear programming and convex optimisation
%         \item Other general tools like PCA, semantic analysis, HMMs and inference tools, Metropolis-Hastings Algorithm, Decision Boundaries
%         \item Backtesting engine
% \end{itemize}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1. Not much

% 2.a Finance related statistical analysis, problems and considerations for financial algorithms
% 2.b Research into advanced mathematics (Dexter's notes of maths tripos)
% 2.c Quantitative Risk Modelling: (VaR, Kelly Criterion).
% 2.d Alpha Generation: Transforming raw signal processing theory into trading signals.
% 3. **No*

% 4. Yes, trivially listed some above, large and diverse amount of mathematical tools and techniques learnt in my course: 
% No classification so this is critical as it utilises something from near every course i studied

% 5. **No**
% 6.
% -  It is incomplete and outdated (last touched 2 years ago), Significant work to iron out issues (1 week), high reward.
% -  Add parts on Decision making, particularly influenced by my neuroscience course like Decision boundaries etc for a biological interpretation
% - integrate **BACKTESTING ENGINE** In finance, a strategy is useless without a rigorous, event-driven backtest implementation that accounts for look-ahead bias.
