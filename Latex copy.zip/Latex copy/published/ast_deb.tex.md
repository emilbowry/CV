
\ifattr{web_based}{%
\title{\textbf{AST Debug Logger:}} 
\location{%
    \makebox[0pt][r]{{\small{\url{https://github.com/emilbowry/editor}}}}
}
\begin{position}
\vspace*{-0.15in}
\par
}{}


\ifattr{math_based}{\textbf{AST Debug Logger:}}{}
A debugging tool that intercepts Python code before execution to toggle any `debug' flags, even from orphans and disconnected nested code. It also intercepts and saves a logs.

\ifattr{web_based}{%
\end{position}
}{}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1. Saves time for development and testing

% 2.a Advanced Python manipulation
% 2.b Compiler Theory: Understanding Abstract Syntax Trees and Visitor patterns.
% 2.c Instrumentation: Injecting observability into code at runtime (similar to how high-frequency trading platforms profile code).
% 3. Uses AST to manipulate source code for JIT execution

% 4. **NO**

% 5. Potentially, will have to reread the source

% 6. Finalise and clean up code
