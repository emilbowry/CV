

\ifattr{web_based}{%
\title{\textbf{Code Editor:}}  % ADD SPECIFIC TAKEAWAYS
\location{%
    \makebox[0pt][r]{{\small{\url{https://github.com/emilbowry/editor}}}}
}
\begin{position}
\vspace*{-0.15in}
\par
}{}


\ifattr{math_based}{\textbf{Code Editor:}
A fork of Microsoft VSCode that:
\begin{itemize} 
        \item Improves supply chain security by removing telemetry ``at the source''.
        \item Removes LLM, MCP and agentic AI integrations and bloat.
        \item Adds new features, like a persistent homepage, and cross-codebase note taking system.
\end{itemize}
}{}

\ifattr{web_based}{%
A fork of Microsoft VSCode that: Improves supply chain security by removing telemetry ``at the source'';  Removes LLM, MCP and agentic AI; and adds new features, like a persistent homepage, and cross-codebase note taking system.
\end{position}
}{
}

% \end{position}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1.a Removing bloat from LLM, MCP and agetic AI integrations
% 1.b Supply Chain Security, removing telemetry "at the source" rather than just blocking the URL (network level), you guarantee that data never leaves the memory buffer.

% 2. Brownfield Development: Navigating, understanding, and modifying a massive,, and foreign codebase (Microsoft VSCode) without causing regression errors.
%     - Identifing and surgically removing deeply coupled subsystems (Telemetry/LLMs) without crashing the application. This requires tracing execution paths across thousands of files.
% 2.b API Design & Shimming: "Rectifying internal APIs" writing Interface Adapters. When i removed a subsystem, i had to create dummy interfaces or valid return states so dependent modules wouldn't panic—a critical skill for maintaining system stability.
% 2.c Polyglot Adaptability: Learning a new language (TypeScript/Electron framework) by reading production-grade code rather than tutorials.
% 2.d Privacy Engineering: Auditing code for data exfiltration points.
% 2.e Comprimising to version lock in and future api issues
% 2.f Build System management: Compiling complex Electron apps from source, Undestanding of CI/CD pipelines (useful relation to my own development of one for AI compatible web stuff)

% 3. **NO**

% 4. **NO**

% 5. **NO**

% 6. Readme, qualitively explain changes, build criteria etc

