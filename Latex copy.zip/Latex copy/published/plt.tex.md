

\ifattr{web_based}{%
\title{\textbf{Plotting Tools:}}  % ADD SPECIFIC TAKEAWAYS
\location{%
    \makebox[0pt][r]{{\small{\url{https://github.com/emilbowry/Plots}}}} \\
    \makebox[0pt][r]{{\small{\url{https://pypi.org/project/plottingtools-emilbowry}}}}
}
\begin{position}
\vspace*{-0.15in}

\par
}{}


\ifattr{math_based}{\textbf{Plotting Tools:}}{}
Extension of the Python Plotly library to make 4+ dimensional correlations intuitive to the human eye, using metaprogramming techniques to create a robust and adaptable framework.
\ifattr{web_based}{
\end{position}}{}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1. Curse of Dimensionality: Making 4+ dimensional correlations intuitive to the human eye.

% 2.a Advanced Python, library and api monkey patching
% 2.b API Design: Creating ergonomic wrappers around complex libraries.

% 3. Bypassing jupyter kernel limitations, metaprogramming and UI manipulation with Python

% 4. **NO**

% 5. **NO**

% 6. Readme and add comments, finalise tests of kernel bypassing and restricted direct Plotly module manipulation that mitigates downstream consequences


