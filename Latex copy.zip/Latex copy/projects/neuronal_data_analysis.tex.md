\textbf{Neural Data Analysis:}  % BE MORE SPECIFIC
\ifattr{math_based}{Built a simulation framework for Lateral Intraparietal Cortex (LIP) neuron impulses, in order to analyse stochastic models The core objective was to evaluate and test different statistical models for varying models.
The framework included:
\begin{itemize}
	\item Modeled neuron impulse with Stochastic Differential Equations (SDEs), and HMM approximations.
    \item Used Bayesian Inference for parameter estimation and model mismatch and brittleness quantification.
    \item Engineered a custom ETL framework to standardise heterogeneous scientific data formats, enabling centralized statistical analysis (e.g., Fano-Factor, PSTH) from legacy lab methods.
\end{itemize}}
{Built an Extract, Transform, Load (ETL) framework for Lateral Intraparietal Cortex (LIP) neuron impulses, in order to analyse stochastic models The core objective was to evaluate statistical models for varying simulation parameters.}
% note the ETL and analysis directly influenced the creation of my plotting tool

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1.a Inconsistent and poor structure of lectures code
% 1.b Stochastic Simulation Reproducibility: creating a deterministic framework for testing probabilistic models.
% 2. Uniform pipeline to compute many simulations types, metrics, statistical tests
% 2.b Data Pipeline Engineering: ETL (Extract, Transform, Load) processes for scientific data.
% 2.c Monte Carlo Simulation: Generating synthetic data distributions.

% 3. **Plotting** but that was formalised in my plotting library

% 4.a Stochastic Differential Equations (SDEs): (Implied if simulating diffusion/ramp models).
% 4.b Point Processes: Modeling spike trains (Poisson processes).


% 5. Caching simulations (not novel), potentially integrate module-type data, data structure manipulation to prevent recomputing differnet "views" of the same fundamental data

% 6. Finalise + publish results

