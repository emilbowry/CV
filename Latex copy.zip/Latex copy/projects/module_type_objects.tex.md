\textbf{Module Type Objects:} % Is this even useful
Built a parallel object system using modules as the core components in Python to allow for more flexible and better controlled attributes.%
\ifattr{math_based}{Used to prototype experiments for Kleene's 3-VL with the native Python singletons (True, False and None) and symmetrise or/and short circuiting.}{}



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% 1. Inconvient language restrictions in Python 
% 2. Deep understanding of the Python language, underlying CPython low-level implementations
% 3. Using modules as a parallel object system
% 4. **NO*
% 5.a Potentially significantly lower overhead for processing objects
% 5.b Namespace Lookup Optimization: Bypassing standard __dict__ lookups for static module properties.
% 6. **Important, time efficiency characterisations**, finalise + publish