\textbf{Integrated Design Project:} % NEEDS ACTIONABLE TAKEAWAY
Group Project building a self-navigating robot -- my contributions to the software led us to coming 2nd place in a University wide robotics competition.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

