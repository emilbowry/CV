\textbf{iCloud Find My messaging service:} 
A system to piggyback on Apple's ``Find my iPhone'' API to remotely communicate between devices without knowledge of any identifiers like IP addresses (side-channel analysis).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% 1. Cross device communication without knowledge of IP addresses

% 2.a Using an underutilised API to by-pass the restrictions of the device information 

% 2.b System knowledge of MacOS notification database, SQL
% 2.c Side-Channel Analysis: Exploiting an existing protocol for an unintended data transfer purpose.
% 2.d Protocol Reverse Engineering: Analysing packet payloads/database structures without documentation.

% 3. **NO**

% 4. **NO**

% 5. **NO**

% 6. Add more comments, and clean up published code



