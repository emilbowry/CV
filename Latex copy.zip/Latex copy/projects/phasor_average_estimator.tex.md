% Latex/projects/phasor_average_estimator.tex

\par
\textbf{Phasor Average Estimator}:
\ifattr{math_based}{%
	A Non-parametric, Recursive Bayesian Estimator that modelled event streams as a superposition of phasors, enabling Zero-Lag estimation. It allows us to:
	\begin{itemize}
		\item Filter noise and jitter, via phase interference without requiring evidence accumulation windows.
		\item Normalise likelihoods via magnitude-weighted Phase Coherence, utilising the Triangle Inequality to guarantee a probability space $\in [0,1]$ regardless of amplitude variance.
		\item Eliminate arbitrary exogenous hyperparameters via these natural geometric bounds.
	\end{itemize}
}{%
	Developed a scale-invariant, Phasor-based Statistical Model to solve hardware jitter and Inter-Symbol Interference (ISI), in a Molecular Communication system. It provided zero-lag estimation, unlike moving averages; retained phase information, unlike mixture models; and provided a non-parameteric way to estimate state.
}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1.             What does it solve or fix?                %
% 2.          What skills does it demonstrate?             %
% 3.         Does it use show novel techniques?            %
% 4.    Does it use any advanced mathematical tools?       %
% 5.     Does it implement any novel optimisations?        %
% 6.     Does it require any extra work or changes?        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 1. 
% 	- Signal noise, jitter and instability to estimate ground truth in a communication signal.
% 	- Requirement for instant reactions
%   - Zero-Lag Estimation: Unlike moving averages which introduce phase lag, phasor summation preserves phase information.

% 2. Control theory, error control, probability, and circular mathematics, frequency analysis, Bayesian inference (to discount other models)

% 3.a Simulates binary signals as complex, time-evolving wave-forms of information
% 3.b Non-parametric State Estimation: It adapts without needing pre-tuned hyperparameters (like a damping ratio).
% 4. Not really, but uses simple techniques in a unique way
% 5. Finalise readme and diagrams and comments in published repo