\name{{\huge Emilian Joseph Bowry} % Fullname?
{\newline \footnotesize 07831799619 \quad emil.bowry@icloud.com \quad \url{https://github.com/emilbowry}}} % Does this need to be evenly spaced